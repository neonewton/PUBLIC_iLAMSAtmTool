# core/__init__.py

from .config import SeleniumConfig, get_config, set_config
