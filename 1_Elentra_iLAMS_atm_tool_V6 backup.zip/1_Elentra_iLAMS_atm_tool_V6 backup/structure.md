1_Elentra_iLAMS_atm_tool_V6

core
   backend_1_Lesson_Link_Upload.py
   backend_2_Bulk_Search_Users.py
   backend_3_Bulk_User_Excel_Gen.py
   backend_4_Bulk_Courses_Archive.py
   config.py
   selenium_utils.py
   theme.py

pages
   1_Bulk_Lesson_Link_Upload.py
   2_Bulk_Search_Users.py
   3_[Cloud]_Bulk_User_Excel_Gen.py
   4_Bulk_Courses_Archive.py

tests
   test_bulk_courses_archive.py
   test_bulk_excel_generation.py
   test_bulk_search_users.py
   test_elentra_link_upload.py

venv
Elentra_iLAMS_atm_tool_V6.spec
Home.py
README main.md
README testing.md

requirements.txt